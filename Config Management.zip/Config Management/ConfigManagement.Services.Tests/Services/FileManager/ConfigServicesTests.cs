﻿using ConfigManagement.Services.Services.FileManager;
using ConfigManagement.Shared;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigManagement.Services.Tests.Services.FileManager
{
    [TestFixture]
    public class ConfigServicesTests
    {
        private ConfigServices configServices;
        private Mock<IConfigServices> mockConfigServices;

        [SetUp]
        public void SetUp()
        {
            configServices = new ConfigServices();
            mockConfigServices = new Mock<IConfigServices>();
        }

        [Test]
        public async Task ParseConfigFile_ValidFilePath_ReturnsServerConfigs()
        {
            
            string filePath = "validFilePath";
            string[] fileLines = { ";START SERVER_TYPE", "KEY1=VALUE1", ";END" };
            Dictionary<string, Dictionary<string, string>> expectedServerConfigs = new Dictionary<string, Dictionary<string, string>>
            {
                { "SERVER_TYPE", new Dictionary<string, string> { { "KEY1", "VALUE1" } } }
            };

            mockConfigServices.Setup(cs => cs.ParseConfigFile(filePath)).ReturnsAsync(expectedServerConfigs);

           
            var result = await mockConfigServices.Object.ParseConfigFile(filePath);

            
            Assert.That(result, Is.EqualTo(expectedServerConfigs));
        }

        [Test]
        public async Task GetConfigData_ValidServerConfigs_ReturnsImportConfigs()
        {
            // Arrange
            Dictionary<string, Dictionary<string, string>> serverConfigs = new Dictionary<string, Dictionary<string, string>>
            {
                {
                    "SERVER_TYPE_1", new Dictionary<string, string>
                    {
                        { "SERVER_NAME", "Server1" },
                        { "URL", "http://server1.com" },
                        { "DB", "Database1" },
                        { "IP_ADDRESS", "192.168.1.1" },
                        { "DOMAIN", "domain1.com" },
                        { "COOKIE_DOMAIN", "cookie_domain1.com" }
                    }
                },
                {
                    "SERVER_TYPE_2", new Dictionary<string, string>
                    {
                        { "SERVER_NAME", "Server2" },
                        { "URL", "http://server2.com" },
                        { "DB", "Database2" },
                        { "IP_ADDRESS", "192.168.1.2" },
                        { "DOMAIN", "domain2.com" },
                        { "COOKIE_DOMAIN", "cookie_domain2.com" }
                    }
                }
            };

            List<ImportConfig> expectedImportConfigs = new List<ImportConfig>
            {
                new ImportConfig
                {
                    SERVER_TYPE = "SERVER_TYPE_1",
                    SERVER_NAME = "Server1",
                    URL = "http://server1.com",
                    DB = "Database1",
                    IP_ADDRESS = "192.168.1.1",
                    DOMAIN = "domain1.com",
                    COOKIE_DOMAIN = "cookie_domain1.com"
                },
                new ImportConfig
                {
                    SERVER_TYPE = "SERVER_TYPE_2",
                    SERVER_NAME = "Server2",
                    URL = "http://server2.com",
                    DB = "Database2",
                    IP_ADDRESS = "192.168.1.2",
                    DOMAIN = "domain2.com",
                    COOKIE_DOMAIN = "cookie_domain2.com"
                }
            };

            mockConfigServices.Setup(cs => cs.GetConfigData(serverConfigs)).ReturnsAsync(expectedImportConfigs);

            var result = await mockConfigServices.Object.GetConfigData(serverConfigs);

            // Assert
            Assert.That(result, Is.EqualTo(expectedImportConfigs));
        }

        [Test]
        public void RemoveEmptyLinesAfterEquals_ValidFile_RemovesEmptyLines()
        {
            string testFilePath = "testfile.txt";

            List<string> lines = new List<string>
            {
                "key1=value1",
                "key2= ",
                "key3=value3",
                "key4= "
            };

            File.WriteAllLines(testFilePath, lines);

            mockConfigServices.Setup(cs => cs.RemoveEmptyLinesAfterEquals(It.IsAny<string>())).CallBase();

            configServices.RemoveEmptyLinesAfterEquals(testFilePath);

            List<string> resultLines = new List<string>(File.ReadAllLines(testFilePath));
            List<string> expectedLines = new List<string> { "key1=value1", "key3=value3" };
            CollectionAssert.AreEqual(expectedLines, resultLines);

            File.Delete(testFilePath);
        }

        [Test]
        public void InsertEditLines_ValidModel_EditsAndInsertsLines()
        {
            string testFilePath = "testfile.txt";
            List<string> lines = new List<string>
            {
                ";START SERVER_TYPE",
                "URL=oldURL"
            };

            File.WriteAllLines(testFilePath, lines);

            ImportConfig model = new ImportConfig
            {
                SERVER_TYPE = "SERVER_TYPE",
                URL = "newURL",
            };

            mockConfigServices.Setup(cs => cs.InsertEditLines(It.IsAny<ImportConfig>(), It.IsAny<string>())).CallBase();

            configServices.InsertEditLines(model, testFilePath);

            List<string> resultLines = new List<string>(File.ReadAllLines(testFilePath));
            List<string> expectedLines = new List<string>
            {
                ";START SERVER_TYPE",
                "URL=oldURL",
                "URL{SERVER_TYPE}=newURL"
            };
            CollectionAssert.AreEqual(expectedLines, resultLines);

            // Clean up
            File.Delete(testFilePath);
        }
    }
}

