﻿namespace ConfigManagement.Shared
{
    public class ImportConfig
    {
        public string SERVER_TYPE { get; set; }
        public string SERVER_NAME { get; set; } = string.Empty;
        public string URL { get; set; } = string.Empty;
        public string DB { get; set; } = string.Empty;
        public string IP_ADDRESS { get; set; } = string.Empty;
        public string DOMAIN { get; set; } = string.Empty;
        public string COOKIE_DOMAIN { get; set; } = string.Empty;
    }
}
