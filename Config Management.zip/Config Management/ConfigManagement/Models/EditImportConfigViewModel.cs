﻿namespace ConfigManagement.Models
{
    public class EditImportConfigViewModel
    {
        public string ServerName { get; set; }
        public string SettingKey { get; set; }
        public string CurrentValue { get; set; }
        public string NewValue { get; set; } = string.Empty;
    }
}
