﻿using Microsoft.AspNetCore.Mvc;

namespace ConfigManagement.Controllers
{
    public class ImportFileController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> PostFiles(string filePath)
        {
            try
            {
                if (string.IsNullOrEmpty(filePath))
                {
                    ViewBag.ErrorMessage = "No File Name or File Path";
                    return await Task.FromResult(View("Error"));
                }

                if (ModelState.IsValid)
                {
                    return RedirectToAction("Index", "Config", new { filePath = filePath });
                }

                return View("Index");
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                return await Task.FromResult(View("Error"));
            }
        }


    }
}
