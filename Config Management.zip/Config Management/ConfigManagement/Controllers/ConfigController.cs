﻿using ConfigManagement.Services.Services.FileManager;
using ConfigManagement.Shared;
using Microsoft.AspNetCore.Mvc;

namespace ConfigManagement.Controllers
{
    public class ConfigController : Controller
    {
        private readonly IConfigServices _configServices;
        
        public ConfigController(IConfigServices configServices)
        {
            _configServices = configServices;
        }

        public async Task<IActionResult> Index(string filePath)
        {
            try
            {

                ViewBag.FilePath = filePath;

                Dictionary<string, Dictionary<string, string>> serverConfigs = await _configServices.ParseConfigFile(filePath);

                List<ImportConfig> importConfigFile = await _configServices.GetConfigData(serverConfigs);

                return View(importConfigFile);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(ex.Message, "An error occurred while processing your request.");
                return View("Error");
            }
        }


        public async Task<IActionResult> Edit(string filePath, string settingKey)
        {
            try
            {
                
                ViewBag.FilePath = filePath;
                Dictionary<string, Dictionary<string, string>> serverConfigs = await _configServices.ParseConfigFile(filePath);

                ImportConfig importConfig = new ImportConfig();

                foreach (var serverConfig in serverConfigs)
                {
                    if (serverConfig.Value.GetValueOrDefault("SERVER_NAME", "") == settingKey)
                    {
                        importConfig.SERVER_TYPE = serverConfig.Key;
                        importConfig.SERVER_NAME = serverConfig.Value.GetValueOrDefault("SERVER_NAME", "");
                        importConfig.URL = serverConfig.Value.GetValueOrDefault("URL", "");
                        importConfig.DB = serverConfig.Value.GetValueOrDefault("DB", "");
                        importConfig.IP_ADDRESS = serverConfig.Value.GetValueOrDefault("IP_ADDRESS", "");
                        importConfig.DOMAIN = serverConfig.Value.GetValueOrDefault("DOMAIN", "");
                        importConfig.COOKIE_DOMAIN = serverConfig.Value.GetValueOrDefault("COOKIE_DOMAIN", "");
                    }
                }

                return View(importConfig);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ImportConfig model, string filePath)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    
                    _configServices.InsertEditLines(model, filePath);

                    _configServices.RemoveEmptyLinesAfterEquals(filePath);

                    return RedirectToAction(nameof(Index), new { filePath = filePath });
                }
                catch (Exception ex)
                {
                    return NotFound(ex.Message);
                }
            }

            return await Task.FromResult(View(model));
        }
    }
}
