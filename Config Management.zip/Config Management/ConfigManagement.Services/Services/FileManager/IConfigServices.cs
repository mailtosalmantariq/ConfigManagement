﻿using ConfigManagement.Shared;

namespace ConfigManagement.Services.Services.FileManager
{
    public interface IConfigServices
    {
        Task<Dictionary<string, Dictionary<string, string>>> ParseConfigFile(string filePath);
        Task<List<ImportConfig>> GetConfigData(Dictionary<string, Dictionary<string, string>> serverConfigs);
        void RemoveEmptyLinesAfterEquals(string filePath);
        void InsertEditLines(ImportConfig model, string filePath);
    }
}