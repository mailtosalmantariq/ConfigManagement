﻿using ConfigManagement.Shared;

namespace ConfigManagement.Services.Services.FileManager
{
    public class ConfigServices : IConfigServices
    {
        private Dictionary<string, Dictionary<string, string>> serverConfigs;

        public ConfigServices()
        {
            serverConfigs = new Dictionary<string, Dictionary<string, string>>();
        }

        public async Task<Dictionary<string, Dictionary<string, string>>> ParseConfigFile(string filePath)
        {
            Dictionary<string, Dictionary<string, string>> serverConfigs = new Dictionary<string, Dictionary<string, string>>();

            try
            {
                string currentServer = "";
                foreach (string line in File.ReadLines(filePath))
                {
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            if (line.StartsWith(";START"))
                            {
                                currentServer = line.Substring(line.IndexOf("START") + 5).Trim();
                                serverConfigs[currentServer] = new Dictionary<string, string>();
                            }
                            else if (line.StartsWith(";END"))
                            {
                                currentServer = "";
                            }
                            else
                            {
                                string[] parts = line.Split(new char[] { '=' }, 2);

                                string key = parts[0].Trim();
                                if (key.Contains("{"))
                                {
                                    int index = key.IndexOf("{");
                                    key = key.Substring(0, index);
                                }

                                string value = parts[1].Trim();

                                if (currentServer != "" && !serverConfigs[currentServer].ContainsKey(key))
                                {
                                    serverConfigs[currentServer][key] = value;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error parsing line: {line}. Exception: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file: {filePath}. Exception: {ex.Message}");
            }

            return await Task.FromResult(serverConfigs);
        }


        public async Task<List<ImportConfig>> GetConfigData(Dictionary<string, Dictionary<string, string>> serverConfigs)
        {

            List<ImportConfig> importConfigs = new();

            foreach (var serverConfig in serverConfigs)
            {
                ImportConfig importConfig = new ImportConfig
                {
                    SERVER_TYPE = serverConfig.Key,
                    SERVER_NAME = serverConfig.Value.GetValueOrDefault("SERVER_NAME", ""),
                    URL = serverConfig.Value.GetValueOrDefault("URL", ""),
                    DB = serverConfig.Value.GetValueOrDefault("DB", ""),
                    IP_ADDRESS = serverConfig.Value.GetValueOrDefault("IP_ADDRESS", ""),
                    DOMAIN = serverConfig.Value.GetValueOrDefault("DOMAIN", ""),
                    COOKIE_DOMAIN = serverConfig.Value.GetValueOrDefault("COOKIE_DOMAIN", "")
                };

                importConfigs.Add(importConfig);
            }


            return await Task.FromResult(importConfigs);
        }

        public void RemoveEmptyLinesAfterEquals(string filePath)
        {
            try
            {
                List<string> lines = new List<string>(File.ReadAllLines(filePath));

                List<int> indicesToRemove = new List<int>();
                for (int i = 0; i < lines.Count; i++)
                {
                    int equalsIndex = lines[i].IndexOf('=');
                    if (equalsIndex != -1)
                    {
                        string afterEquals = lines[i].Substring(equalsIndex + 1).Trim();
                        if (string.IsNullOrEmpty(afterEquals))
                        {
                            indicesToRemove.Add(i);
                        }
                    }
                }

                // Remove lines with identified indices
                for (int i = indicesToRemove.Count - 1; i >= 0; i--)
                {
                    lines.RemoveAt(indicesToRemove[i]);
                }

                // Write the modified lines back to the file
                if (indicesToRemove.Count > 0)
                {
                    File.WriteAllLines(filePath, lines);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error occurred while removing empty lines after equals. Exception: {ex.Message}");
                throw; 
            }
        }


        public void InsertEditLines(ImportConfig model, string filePath)
        {
            string targetString = $";START {model.SERVER_TYPE}";

            List<string> lines = new List<string>(System.IO.File.ReadAllLines(filePath));

            bool blURL = true;
            bool blDB = true;
            bool blIP_ADDRESS = true;
            bool blDomain = true;
            bool blCookie_Domain = true;

            // Find the index of the target line
            int index = -1;
            int indexDup = -1;
            int indexNew = -1;

            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].StartsWith(targetString))
                {
                    index = i + 1;
                    indexDup = i + 1;
                    indexNew = i + 1;
                    break;
                }
            }

            int indexRest = indexNew + 6;
            var model_URL = $"URL{{{model.SERVER_TYPE}}}=";
            var model_Db = $"DB{{{model.SERVER_TYPE}}}=";
            var model_Ip_address = $"IP_ADDRESS{{{model.SERVER_TYPE}}}=";
            var model_Domain = $"DOMAIN{{{model.SERVER_TYPE}}}=";
            var model_Cookie_Domain = $"COOKIE_DOMAIN{{{model.SERVER_TYPE}}}=";

            // Insert or Edit the new lines after the target line
            if (index != -1)
            {
                //Edit the existing line
                indexDup++;
                while (indexDup < lines.Count && !lines[indexDup].StartsWith(";END"))
                {
                    var check = lines[indexDup].StartsWith(model_Ip_address);
                    if (lines[indexDup].StartsWith("URL=") && model.SERVER_TYPE == "DEFAULTS" && blURL == true)
                    {
                        lines[indexDup] = "URL=" + model.URL;
                        blURL = false;
                        continue;
                    }
                    else if (lines[indexDup].StartsWith(model_URL) && model.SERVER_TYPE != "DEFAULTS" && blURL == true)
                    {
                        lines[indexDup] = model_URL + model.URL;
                        blURL = false;
                        continue;

                    }
                    else if (lines[indexDup].StartsWith("DB=") && model.SERVER_TYPE == "DEFAULTS" && blDB == true)
                    {
                        lines[indexDup] = "DB=" + model.DB;
                        blDB = false;
                        continue;

                    }
                    else if (lines[indexDup].StartsWith(model_Db) && model.SERVER_TYPE != "DEFAULTS" && blDB == true)
                    {
                        lines[indexDup] = model_Db + model.DB;
                        blDB = false;
                        continue;

                    }
                    else if (lines[indexDup].StartsWith("IP_ADDRESS=") && model.SERVER_TYPE == "DEFAULTS" && blIP_ADDRESS == true)
                    {
                        lines[indexDup] = "IP_ADDRESS=" + model.IP_ADDRESS;
                        blIP_ADDRESS = false;
                        continue;
                    }
                    else if (lines[indexDup].StartsWith(model_Ip_address) && model.SERVER_TYPE != "DEFAULTS" && blIP_ADDRESS == true)
                    {
                        lines[indexDup] = model_Ip_address + model.IP_ADDRESS;
                        blIP_ADDRESS = false;
                        continue;

                    }
                    else if (lines[indexDup].StartsWith("DOMAIN=") && model.SERVER_TYPE == "DEFAULTS" && blDomain == true)
                    {
                        lines[indexDup] = "DOMAIN=" + model.DOMAIN;
                        blDomain = false;
                        continue;

                    }
                    else if (lines[indexDup].StartsWith(model_Domain) && model.SERVER_TYPE != "DEFAULTS" && blDomain == true)
                    {
                        lines[indexDup] = model_Domain + model.DOMAIN;
                        blDomain = false;
                        continue;

                    }
                    else if (lines[indexDup].StartsWith("COOKIE_DOMAIN=") && blCookie_Domain == true)
                    {
                        lines[indexDup] = "COOKIE_DOMAIN=" + model.COOKIE_DOMAIN;
                        blCookie_Domain = false;
                        continue;

                    }
                    else if (lines[indexDup].StartsWith(model_Cookie_Domain) && blCookie_Domain == true)
                    {
                        lines[indexDup] = model_Cookie_Domain + model.COOKIE_DOMAIN;
                        blCookie_Domain = false;
                        continue;
                    }

                    indexDup++;
                }


                indexNew++; // Add New Lines
                            //while (indexNew < lines.Count && !lines[indexNew].StartsWith(";END"))
                while (indexNew < indexRest)
                {
                    // Insert the new line if the corresponding line is not already present
                    if (!string.IsNullOrWhiteSpace(model.URL) && model.SERVER_TYPE == "DEFAULTS" && blURL == true)
                    {
                        lines.Insert(indexNew++, "URL=" + model.URL);
                        blURL = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.URL) && model.SERVER_TYPE != "DEFAULTS" && blURL == true)
                    {
                        lines.Insert(indexNew++, model_URL + model.URL);
                        blURL = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.DB) && model.SERVER_TYPE == "DEFAULTS" && blDB == true)
                    {
                        lines.Insert(indexNew++, "DB=" + model.DB);
                        blDB = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.DB) && model.SERVER_TYPE != "DEFAULTS" && blDB == true)
                    {
                        lines.Insert(indexNew++, model_Db + model.DB);
                        blDB = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.IP_ADDRESS) && model.SERVER_TYPE == "DEFAULTS" && blIP_ADDRESS == true)
                    {
                        lines.Insert(indexNew++, "IP_ADDRESS=" + model.IP_ADDRESS);
                        blIP_ADDRESS = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.IP_ADDRESS) && model.SERVER_TYPE != "DEFAULTS" && blIP_ADDRESS == true)
                    {
                        lines.Insert(indexNew++, model_Ip_address + model.IP_ADDRESS);
                        blIP_ADDRESS = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.DOMAIN) && model.SERVER_TYPE == "DEFAULTS" && blDomain == true)
                    {
                        lines.Insert(indexNew++, "DOMAIN=" + model.DOMAIN);
                        blDomain = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.DOMAIN) && model.SERVER_TYPE != "DEFAULTS" && blDomain == true)
                    {
                        lines.Insert(indexNew++, model_Domain + model.DOMAIN);
                        blDomain = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.COOKIE_DOMAIN) && model.SERVER_TYPE == "DEFAULTS" && blCookie_Domain == true)
                    {
                        lines.Insert(indexNew++, "COOKIE_DOMAIN=" + model.COOKIE_DOMAIN);
                        blCookie_Domain = false;
                        continue;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.COOKIE_DOMAIN) && model.SERVER_TYPE != "DEFAULTS" && blCookie_Domain == true)
                    {
                        lines.Insert(indexNew++, model_Cookie_Domain + model.COOKIE_DOMAIN);
                        blCookie_Domain = false;
                        continue;
                    }

                    indexNew++;
                }


            }

            // Write the modified lines back to the file
            File.WriteAllLines(filePath, lines);
            
        }
    }
}
